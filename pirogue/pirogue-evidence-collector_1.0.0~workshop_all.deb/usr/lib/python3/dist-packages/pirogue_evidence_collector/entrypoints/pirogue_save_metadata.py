from pathlib import Path

from pirogue_evidence_collector.file_handler.metadata import BatchExporter


def main():
    pass  # ToDo - Implement the main function
