
class TlpPap:
    RED = 'RED'
    AMBER = 'AMBER'
    GREEN = 'GREEN'
    WHITE = 'WHITE'


class TLP(TlpPap):
    """TLP enumeration shorthand"""


class PAP(TlpPap):
    """PAP enumeration shorthand"""
