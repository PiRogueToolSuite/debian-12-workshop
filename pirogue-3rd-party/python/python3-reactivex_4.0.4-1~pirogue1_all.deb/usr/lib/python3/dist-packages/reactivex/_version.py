__version__ = "0.0.0"  # NOTE: version will be written by publish script
