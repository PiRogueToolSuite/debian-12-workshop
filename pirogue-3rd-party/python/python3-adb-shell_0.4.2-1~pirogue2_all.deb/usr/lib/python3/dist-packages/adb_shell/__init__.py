# Copyright (c) 2021 Jeff Irion and contributors
#
# This file is part of the adb-shell package.

"""ADB shell functionality.

"""


__version__ = '0.4.2'
